namespace Library.Web.Configuration
{
    public class EnvironmentConfig
    {
        public string LibraryWebApiServiceHost { get; set; }
    }
}