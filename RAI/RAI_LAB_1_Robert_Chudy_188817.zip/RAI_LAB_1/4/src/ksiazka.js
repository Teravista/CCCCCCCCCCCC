import { expect } from 'chai'
export function Ksiazka(autor,tytul,cena,wydawnicstwo,slowa_kluczowe,wypozyczajacy){
this.autor = autor;
this.tytul = tytul;
this.cena = cena;
this.wydawnicstwo = wydawnicstwo;
this.slowa_kluczowe = slowa_kluczowe;
this.wypozyczajacy = wypozyczajacy;
}