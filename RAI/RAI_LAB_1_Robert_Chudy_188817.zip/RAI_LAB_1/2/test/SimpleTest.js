import { expect } from 'chai'
describe('canary-tests', function()
{
it('should always pass the canary test', function()
{
expect(true).to.eql(true);
});
});