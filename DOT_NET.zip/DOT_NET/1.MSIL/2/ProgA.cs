namespace JP_NET.Lab1
{
 class Program
 {
 public static void Main()
 {
 ClassA a = new ClassA();
 a.MethodOfClassA();
 a.A = 1;
 a.b = 2;
 }
 }
}
