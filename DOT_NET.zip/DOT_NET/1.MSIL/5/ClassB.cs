namespace JP_NET.Lab1
{
 public class ClassB
 {
 public void MethodOfClassB()
 {
 System.Console.WriteLine("Wydruk z klasy B.");
 }
 }
}
